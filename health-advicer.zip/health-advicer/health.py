from flask import Flask, render_template, request, redirect, url_for, session, flash
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash

import random

app = Flask(__name__)
app.secret_key = "Hello_World!"
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///baseinfo.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

# User model
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(150), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)
    email = db.Column(db.String(150), unique=True, nullable=False)

# Renderer
@app.route('/')
def homepage():
    return render_template('login.html')

# Route: home/intro page
@app.route('/home')
def home():
    if 'user_id' in session:
        user = User.query.get(session['user_id'])
        if user:
            return render_template('home.html', username=user.username)
    return redirect(url_for('login'))

# Route: login
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        user = User.query.filter_by(username=username).first()

        if user and check_password_hash(user.password, password):
            session['user_id'] = user.id
            return redirect(url_for('home'))
        else:
            flash("Username or password is incorrect.")
            return redirect(url_for('login'))
    else:
        return render_template('login.html')

# Route: signup
@app.route('/signup', methods=['POST'])
def signup():
    uname = request.form['newUsername']
    pw = request.form['newPassword']
    email = request.form['email']

    existing_user = User.query.filter((User.username == uname) | (User.email == email)).first()
    if existing_user:
        flash('Username or email already exists.', 'error')
        return redirect(url_for('login'))

    hashed_password = generate_password_hash(pw)
    new_user = User(username=uname, password=hashed_password, email=email)
    db.session.add(new_user)
    db.session.commit()

    flash('Signup successful! Please login.', 'success')
    return redirect(url_for('login'))

# Route: logout
@app.route('/logout')
def logout():
    session.pop('user_id', None)
    flash('Logged out successfully.', 'info')
    return redirect(url_for('login'))

# Route: settings
@app.route('/settings', methods=['GET', 'POST'])
def settings():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    user = User.query.get(session['user_id'])

    if request.method == 'POST':
        new_username = request.form['username']
        new_email = request.form['email']

        # Check for username/email duplicates in other accounts
        existing_user = User.query.filter(
            ((User.username == new_username) | (User.email == new_email)) & 
            (User.id != user.id)
        ).first()

        if existing_user:
            flash("Username or email is already taken.", "error")
            return redirect(url_for('settings'))

        user.username = new_username
        user.email = new_email

        if request.form['password']:
            user.password = generate_password_hash(request.form['password'])

        db.session.commit()
        flash("Settings updated successfully!", "success")
        return redirect(url_for('settings'))

    return render_template('settings.html', username=user.username, email=user.email)

# Route: Health Advices
@app.route('/health-advices', methods=['GET', 'POST'])
def health_advices():
    return render_template('health_advices.html')

# Route: Healthy Food Tips
@app.route('/healthy-food-tips', methods=['GET', 'POST'])
def healthy_food_tips():
    return render_template('healthy_food_tips.html')

# Run server
if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)



#    @app.route('/check-in', methods=['POST'])
#    def check_in():
#        mood = request.form['mood']
#        energy = request.form['energy']
#        hydration = request.form['hydration']
#        flash("Check-in saved successfully!")
#        return redirect(url_for('home'))